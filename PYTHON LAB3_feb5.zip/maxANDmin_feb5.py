#Program to find: Max and Min value
#USN = 1RUA25BCA0056
#Name : M R Gangamma

a=int(input("enter the 1st num"))
b=int(input("enter the 2nd num"))
c=int(input("enter the 3rd num"))
if(a>b and a>c):
    print(" a is max")
elif(b>a and b>c):
    print("b is max")
else:
    print("c is max")

if(a<b and a<c):
    print("a is min")
elif(b<a and b<c):
    print("b is min")
else:
    print("c is min")
