#Program to find: simple calculator
#USN = 1RUA25BCA0056
#Name : M R Gangamma


a=float(input("enetr the 1st num"))
b=float(input("enetr the 2nd num"))
op=int(input("1 add, 2 sub, 3 prod, 4 div"))

match op:
    case 1:
        print(a+b)
    case 2:
        print(a-b)
    case 3:
        print(a*b)
    case 4:
        print(a/b)
    case _:
        print("invalid")
         
          
