#Program to find: temperature conversion
#USN = 1RUA25BCA0056
#Name : M R Gangamma

a=float(input("enter the temp"))
op=int(input("1 celsius to farhenite, 2 farenhite to celsius"))

match op:
       case 1:
           print((a*9/5)+32)
       case 2:
           print((a-32)*5/9)
       case _:
           print("invalid")


